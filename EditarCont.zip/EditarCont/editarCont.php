

<?php
class YourClassName {
    public function find($id) {
        $sql = 'SELECT * FROM contratante where id_contratante = :id';
        $stmt = FabricaConexao::Conexao()->prepare($sql);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function delete($id) {
        $sql = 'DELETE FROM contratante WHERE id_contratante = :id';
        $stmt = FabricaConexao::Conexao()->prepare($sql);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        header("Location: ./view/Listacontratante.php");
    }
}

class DAOcontratante {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function insert($contratante) {
        $sql = "INSERT INTO contratante (Nome, Sobrenome, Email, Senha, Endereco, Descricao, Telefone, Dt_Nascimento, servico_forn) VALUES (:Nome, :Sobrenome, :Email, :Senha, :Endereco, :Descricao, :Telefone, :Dt_Nascimento, :servico_forn)";
        $stmt = $this->db->prepare($sql);

        $stmt->bindParam(':Nome', $contratante->getNome());
        $stmt->bindParam(':Sobrenome', $contratante->getSobrenome());
        $stmt->bindParam(':Email', $contratante->getEmail());
        $stmt->bindParam(':Senha', $contratante->getSenha());
        $stmt->bindParam(':Endereco', $contratante->getEndereco());
        $stmt->bindParam(':Descricao', $contratante->getDescricao());
        $stmt->bindParam(':Telefone', $contratante->getTelefone());
        $stmt->bindParam(':Dt_Nascimento', $contratante->getDtNascimento());
        $stmt->bindParam(':servico_forn', $contratante->getServicoForn());

        return $stmt->execute();
    }

    public function update($contratante) {
        $sql = "UPDATE contratante SET Nome = :Nome, Sobrenome = :Sobrenome, Email = :Email, Senha = :Senha, Endereco = :Endereco, Descricao = :Descricao, Telefone = :Telefone, Dt_Nascimento = :Dt_Nascimento, servico_forn = :servico_forn WHERE id_contratante = :id_contratante";
        $stmt = $this->db->prepare($sql);

        $stmt->bindParam(':id_contratante', $contratante->getId());
        $stmt->bindParam(':Nome', $contratante->getNome());
        $stmt->bindParam(':Sobrenome', $contratante->getSobrenome());
        $stmt->bindParam(':Email', $contratante->getEmail());
        $stmt->bindParam(':Senha', $contratante->getSenha());
        $stmt->bindParam(':Endereco', $contratante->getEndereco());
        $stmt->bindParam(':Descricao', $contratante->getDescricao());
        $stmt->bindParam(':Telefone', $contratante->getTelefone());
        $stmt->bindParam(':Dt_Nascimento', $contratante->getDtNascimento());
        $stmt->bindParam(':servico_forn', $contratante->getServicoForn());

        return $stmt->execute();
    }

    public function delete($id) {
        $sql = "DELETE FROM contratante WHERE id_contratante = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':id', $id);

        return $stmt->execute();
    }

    public function find($id) {
        $sql = "SELECT * FROM contratante WHERE id_contratante = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':id', $id);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_OBJ);
    }

    public function getAll() {
        $sql = "SELECT * FROM contratante";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_OBJ);
    }
    
    // Add more methods as needed for your specific use case
}
?>